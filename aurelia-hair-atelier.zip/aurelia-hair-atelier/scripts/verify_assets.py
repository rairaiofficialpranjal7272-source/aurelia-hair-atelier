#!/usr/bin/env python3
"""Check that local img src and CSS url() references resolve to project files.

For a GitHub Pages project site, relative asset references are resolved beneath
https://USERNAME.github.io/aurelia-hair-atelier/ rather than the host root.
"""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse
import re

ROOT = Path(__file__).resolve().parents[1]
BASE = "/aurelia-hair-atelier/"

class ImageReferences(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs = []
    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src:
                self.refs.append(("img", src))

refs = []
for file in sorted(ROOT.glob("*.html")):
    parser = ImageReferences()
    parser.feed(file.read_text(encoding="utf-8"))
    refs.extend((file.name, kind, ref) for kind, ref in parser.refs)
    text = file.read_text(encoding="utf-8")
    refs.extend((file.name, "css url()", ref) for ref in re.findall(r"url\(['\"]?([^'\")]+)", text))

errors = []
for filename, kind, ref in refs:
    if ref.startswith(("data:", "http://", "https://", "//")):
        continue
    if ref.startswith("/"):
        errors.append(f"{filename}: {kind} uses root-absolute URL {ref!r}; it will miss the Pages repository prefix")
        continue
    # Resolve exactly like a browser opening a Pages project site, then map
    # its repository prefix back to this checkout to confirm the target exists.
    target_url = urljoin("https://example.github.io" + BASE, ref)
    target_path = urlparse(target_url).path
    if not target_path.startswith(BASE):
        errors.append(f"{filename}: resolved outside the Pages project prefix: {ref!r} -> {target_path!r}")
        continue
    relative_target = target_path[len(BASE):].split("?", 1)[0].split("#", 1)[0]
    resolved = (ROOT / relative_target).resolve()
    try:
        resolved.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"{filename}: {kind} escapes project root: {ref!r}")
        continue
    if not resolved.is_file():
        errors.append(f"{filename}: missing {kind} target {ref!r} -> {relative_target!r}")
        continue
    if not ref.startswith("./"):
        errors.append(f"{filename}: use explicit ./ relative path for {kind}: {ref!r}")

if errors:
    print("FAIL — image references need attention:")
    print("\n".join(f" - {e}" for e in errors))
    raise SystemExit(1)
print(f"PASS — {len(refs)} local image/CSS reference(s) resolve; all local targets exist and are explicitly relative.")
print(f"PASS — GitHub Pages project-site prefix tested: {BASE}")
